# SentinelMail — Cyber Email Layer

Email threat detection, geolocation, and forensic intelligence platform. Paste
a raw email and SentinelMail parses its headers, checks SPF/DKIM/DMARC,
flags spoofing and phishing indicators, extracts links and IP addresses,
traces those IPs on a map, and lets you save the results as an
investigation case with a printable forensic report.

[![Open in Bolt](https://bolt.new/static/open-in-bolt.svg)](https://bolt.new/~/sb1-sbc11tyf)

## Features

- **Email Analyzer** — parses raw email source, evaluates authentication
  headers, sender/display-name spoofing, lookalike domains, shortened and
  IP-based links, and urgency/scam/phishing language, then produces a
  0–100 threat score.
- **Threat Map** — geolocates extracted IP addresses and visualizes their
  path on a world map, flagging hosting providers and suspicious networks.
- **Live Monitor** — real-time feed of every analysis performed, powered by
  Supabase Realtime.
- **Cases** — save analyses as investigation cases with analyst notes, and
  generate a printable/PDF forensic report.

## Tech stack

- React 18 + TypeScript + Vite
- Tailwind CSS
- Supabase (Postgres, Row Level Security, Realtime, Edge Functions)
- [ip-api.com](https://ip-api.com) for IP geolocation (called from a
  Supabase Edge Function, with results cached in Postgres)

## Prerequisites

- Node.js 18+
- A free [Supabase](https://supabase.com) project
- The [Supabase CLI](https://supabase.com/docs/guides/cli) (only needed if
  you want to deploy the Edge Function or run migrations from your machine)

## Setup

1. **Clone and install**

   ```bash
   git clone https://github.com/<your-username>/Cyber-Email-Layer.git
   cd Cyber-Email-Layer
   npm install
   ```

2. **Create a Supabase project** at [supabase.com](https://supabase.com) if
   you don't already have one.

3. **Run the database migrations.** In the Supabase dashboard, open the SQL
   Editor and run the contents of each file in `supabase/migrations/` in
   order (or, if you have the Supabase CLI linked to your project, run
   `supabase db push`).

4. **Deploy the geolocation Edge Function.** This function looks up IP
   addresses and caches the results.

   ```bash
   supabase functions deploy geolocate --no-verify-jwt
   ```

5. **Configure environment variables.** Copy `.env.example` to `.env` and
   fill in your project's URL and anon key (Project Settings > API in the
   Supabase dashboard):

   ```bash
   cp .env.example .env
   ```

6. **Run the app locally**

   ```bash
   npm run dev
   ```

## Developing in VS Code

Just open the project folder in VS Code — no extra setup required to edit or
run it. A few things are pre-configured for a smoother experience:

- **Recommended extensions** (`.vscode/extensions.json`) — VS Code will prompt
  you to install them on first open: ESLint, Tailwind CSS IntelliSense, and
  the Deno extension (only used for the one file under `supabase/functions/`,
  which runs on Deno rather than Node — see note below).
- **Press F5** to launch the dev server and open the app in a debuggable
  Chrome window, with breakpoints working directly in your `.tsx`/`.ts`
  source files.
- Or run it the normal way in the integrated terminal: `npm run dev`.

**Why `supabase/functions/` looks different:** that folder is a Supabase Edge
Function, which runs on Deno, not Node — it uses `Deno.serve(...)` and
`npm:package@version` import specifiers that are invalid in the rest of the
project. VS Code is configured (via `deno.enablePaths`) to only apply Deno's
language server to that folder, so it won't conflict with the Node/Vite
tooling used everywhere else in `src/`. You don't need Deno installed locally
to edit it — it only actually runs when deployed with `supabase functions
deploy`.

## Available scripts

| Command             | Description                               |
| ------------------- | ------------------------------------------ |
| `npm run dev`       | Start the Vite dev server                  |
| `npm run build`     | Type-check and build for production        |
| `npm run preview`   | Preview the production build locally       |
| `npm run lint`      | Run ESLint                                 |
| `npm run typecheck` | Run the TypeScript compiler with no emit   |

## Deployment

This is a static Vite build, so it can be hosted anywhere that serves static
files — Vercel, Netlify, GitHub Pages, Cloudflare Pages, etc. Set the two
`VITE_SUPABASE_*` environment variables in your hosting provider's build
settings, then run `npm run build` and deploy the generated `dist/` folder.
The Supabase anon key is meant to be public; access to your data is
controlled by the Row Level Security policies in `supabase/migrations/`.

A GitHub Actions workflow (`.github/workflows/ci.yml`) is included that
type-checks, lints, and builds the project on every push and pull request.

## Security note

This project's RLS policies are intentionally permissive (`anon` and
`authenticated` have full CRUD on all tables) because it's built as a
single-tenant tool with no login screen. If you deploy a public instance and
want to restrict access, add authentication and tighten the policies in
`supabase/migrations/` before going live.

## License

MIT — see [LICENSE](./LICENSE).
